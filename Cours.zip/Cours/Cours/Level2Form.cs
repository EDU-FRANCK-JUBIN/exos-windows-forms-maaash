﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Cours
{
    public partial class Level2Form : Form
    {
        private MainForm parentForm;
        public Level2Form(MainForm parent)
        {
            InitializeComponent();
            parentForm = parent;

        }

        private void btMyParent_Click(object sender, EventArgs e)
        {
            string s = this.Owner.Name;
            // Display the name in a message box.
            MessageBox.Show("My Owner.Name is " + s + ".");
        }

      

        private void btSend_Click(object sender, EventArgs e)
        { 
            parentForm.setTbReceive(tbSend.Text);
        }

        private void btReceive_Click(object sender, EventArgs e)
        {
            tbReceive.AppendText(parentForm.getTbSend());
        }
    }
}
